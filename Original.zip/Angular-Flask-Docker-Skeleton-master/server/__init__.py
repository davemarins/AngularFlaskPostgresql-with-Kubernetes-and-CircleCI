# -*- coding: utf-8 -*-
"""Angular-Flask-Docker-Skeleton

    server application package

"""