"""Unittest for testing all routes"""
import unittest
from server.tests.base import BaseTestCase


class TestRoutes(BaseTestCase):
    """Class to test all route methods"""
    pass

if __name__ == '__main__':
    unittest.main()
